const { Schema, model} = require("mongoose");

const OrderSchema = new Schema({
    Name : {type: String, required: true},
    Address : {type:String , required:true},
    Date: {type:Date, default: new Date()},
    Product : {type:String , required:true},
    Quantity : {type:Number , required:true},
    Email : {type:String , required : true }
})

const orderModel = model("order",OrderSchema , "orderList" );
module.exports = {OrderSchema, orderModel}