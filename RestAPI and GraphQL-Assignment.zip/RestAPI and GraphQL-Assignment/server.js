const express = require("express");
const jwt = require("jsonwebtoken");
const {APP_SECRET_KEY  }= require("./config");
const app = express();
const bcrypt = require("bcrypt");

require("./db")

const AuthMiddleware = require("./middleware/auth")
const AdminMiddleware = require("./middleware/admin")

const UserRouter = require("./routes/user");
const ShoppinglistRouter = require("./routes/shoppinglist");
const { ShoppingModel } = require("./schema/shopping");
const { UserModel } = require("./schema/user");
const { orderModel } = require("./schema/order");
const { adminDashboardModel } = require("./schema/adminDashboard");
app.use(express.json());
app.use("/user",  UserRouter)
app.use("/Shopping" ,AuthMiddleware, ShoppinglistRouter)
// app.get("/find-products" ,AuthMiddleware, (req, res) => {
//     const doc = ShoppingModel.findOne({"Price": {$eq:"$276.68"} }, function (err, docs) {
//         if (err){
//             console.log(err)
//         }
//         else{
//             console.log("Result : ", docs);
//         }
//     });
// })






app.post("/orderSubmit",  (req,res)=>{
    try{
        const {body} = req;
        const {Name, Address, Email , Product , Quantity , Date } = body
        if(Name && Address && Email && Product && Quantity && Date  && Name !== "" && Address !== "" && Product !== "" && Quantity !== "" && Email !== ""){            
            const newItem = new orderModel({Name , Address ,  Email , Product ,Date , Quantity})
            const doc =  newItem.save();
        res.json({message: "new order Submitted", id: doc._id})
    
        }
        else{
            res.status(401).json({message: "invalid input"})
        }
    
        
    }
    catch(error){
        res.status(500).json({message: "internal server error"})
    }
  
})

app.get("/adminStatus", AuthMiddleware, AdminMiddleware, (req,res)=>{
   
            const doc = orderModel.find({} , {Name : 1, Address : 1, Date : 1 , Product : 1 , Email : 1,  _id: 0}, function (err, docs) {
                if (err){
                    console.log(err)
                }
                else{
                    console.log("Result : ", docs);               
                    let Curentdate = new Date();
                    let OName = "";
                    let OAddress = "";
                    let OEmail = "";
                    let OProduct = "";
                    let ODateofOrder = new Date();
                    
                    let Status = "";
                    let sendEmail = "";
                    for(var k in docs){
                        OName = docs[k].Name;
                        OAddress = docs[k].Address;
                        OEmail = docs[k].Email;
                        OProduct = docs[k].Product;
                        ODateofOrder = docs[k].Date;
                      
                       if(docs[k].Date = Curentdate - 1 )
                       {
                           OStatus = "Dispatched";
                           OsendEmail = "N"                     
                            
                       }
                       else if ( docs[k].Date >= Curentdate - 2)
                       {
                        OStatus = "Delivered";
                        OsendEmail = "Y"   
                       }
                       else 
                       {
                        OStatus = "In Process";
                        OsendEmail = "N"   
                       }
                    console.log(OName);
                    console.log(OStatus);
                    console.log(OsendEmail);
                    console.log(ODateofOrder);
                    console.log(OAddress);
                    console.log(OEmail);
                    

                    const newItem = new adminDashboardModel({OName , OAddress ,  OEmail , OProduct , ODateofOrder ,OStatus ,OsendEmail })
                    const doc =  newItem.save();
                res.json({message: "new order Submitted", id: doc._id})
                    }
                    

                    res.json({docs})
                }
            });
            
        })

app.get("/userList" ,AuthMiddleware, AdminMiddleware, (req, res) => {
    
    const doc = UserModel.find({}, { email: 1, _id: 0 }, function (err, docs) {
        if (err){
            console.log(err)
        }
        else{
            console.log("Result : ", docs);
        }
    });
    
    
})

app.get("/orderList" ,AuthMiddleware, AdminMiddleware, (req, res) => {
    
    const doc = orderModel.find({}, {  }, function (err, docs) {
        if (err){
            console.log(err)
        }
        else{
            console.log("Result : ", docs);
            res.json({message : "order is here",Name: docs.Quantity})
        }
    });
    
    
})

app.post("/registerAdmin", AuthMiddleware, AdminMiddleware, async (req,res)=>{
    try{
        const {body} = req;
        const {email,password} = body
        if(email && password && email !== "" && password !== ""){
            const encryptedPassword  = await bcrypt.hash(password, 10)
            const newUser = new UserModel({email, password : encryptedPassword })
            const doc =  await   newUser.save();
        res.json({message: "new user added via admin", id: doc._id})
    
        }
        else{
            res.status(401).json({message: "invalid input"})
        }
    
        
    }
    catch(error){
        res.status(500).json({message: "internal server error - admin"})
    }
  
})

app.listen(6701)