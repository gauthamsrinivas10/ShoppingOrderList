const { connect } = require("mongoose");

async function main(){

    const mongourl = "mongodb://localhost:27017/Shopping" 
    connect(mongourl)
}
main();